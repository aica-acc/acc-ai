

from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
import base64
import os
import uuid
from pathlib import Path
from google import genai
from google.genai import types

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

client: genai.Client | None = None
if GEMINI_API_KEY:
    client = genai.Client(api_key=GEMINI_API_KEY)
else:
    client = None  # 키 없으면 None으로 두고, 호출 쪽에서 방어

# 나중에 Gemini 붙일 때 쓸 예정 (지금은 stub)
# from google import genai

# ------------------------------------
# 1) 경로 설정 (로컬 저장 폴더)
# ------------------------------------

# acc-ai/ 기준으로 data/editor_ai_output 폴더 만들기
BASE_DIR = Path(__file__).resolve().parents[2]
OUTPUT_DIR = BASE_DIR / "data" / "editor" / "editor_ai_output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# 나중에 실제로 쓸 모델 이름 (지금은 참조용)
GEMINI_MODEL_DEFAULT = "gemini-3-pro-image-preview"

# Gemini 키는 환경변수로 받을 계획 (지금은 사용 X, stub 단계)
# GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
# client: Optional[genai.Client] = None
# if GEMINI_API_KEY:
#     client = genai.Client(api_key=GEMINI_API_KEY)


# ------------------------------------
# 2) Pydantic 요청/응답 모델
# ------------------------------------

class EditorAiRenderRequest(BaseModel):
    pNo: Optional[int] = None
    canvasImage: str
    layoutType: Optional[str] = None
    model: Optional[str] = None


class EditorAiRenderResponse(BaseModel):
    status: str
    imageUrl: Optional[str] = None
    message: Optional[str] = None


# ------------------------------------
# 3) 유틸 함수들
# ------------------------------------

def decode_data_url_to_bytes(data_url: str) -> bytes:
    """
    data:image/png;base64,xxxx 형태에서 base64 부분만 잘라서 디코딩.
    """
    if "," in data_url:
        _, b64 = data_url.split(",", 1)
    else:
        b64 = data_url
    return base64.b64decode(b64)


def save_bytes_to_file(img_bytes: bytes, suffix: str = ".png") -> Path:
    """
    생성된 이미지를 data/editor_ai_output/ 에 저장하고 경로를 리턴.
    """
    filename = f"editor_ai_{uuid.uuid4().hex}{suffix}"
    path = OUTPUT_DIR / filename
    path.write_bytes(img_bytes)
    return path


def local_path_to_url(path: Path) -> str:
    """
    TODO:
    - 지금은 단순히 'static처럼 보이는 URL 문자열'만 만들어 줌.
    - 나중에 FastAPI StaticFiles mount, Nginx, Flask static 등
      현재 프로젝트 구조에 맞게 실제 URL로 바꾸면 됨.
    """
    # 예: /static/editor_ai/파일명 식으로 가정
    return f"/static/editor_ai/{path.name}"


# ------------------------------------
# 4) Gemini 호출 Stub (나중에 구현)
# ------------------------------------

def call_gemini_3_pro_image(
    base_image: bytes,
    layout_type: Optional[str] = None,
    model_name: Optional[str] = None,
) -> bytes:
    """
    TODO:
    - 여기에서 gemini-3-pro-image-preview를 실제로 호출할 예정.
    - 지금은 아직 요금/세팅 안 해서, 일단 '원본 이미지를 그대로 리턴'하는 stub.
    - 나중에 공식 docs 보고 generate_images / edit_image 형태로 교체.
    """
    
    if client is None:
        return base_image

    model = model_name or GEMINI_MODEL_DEFAULT
    
    prompt_parts = [
        "이 이미지는 축제 포스터/배너의 레이아웃 초안입니다.",
        "텍스트 내용과 배치는 유지하되, 글씨체/광원/입체감만 포스터처럼 자연스럽게 재렌더링해 주세요.",
        "한글 텍스트는 절대 변경하지 말고, 더 또렷하고 가독성 좋게 만들어 주세요.",
        "글씨의 색깔과 글씨체는 변경해도 되지만 글씨가 망가질정도의 글씨체 변경은 자제하고 이펙트와 효과 색깔로 표현하세요",
        "실제 디자이너라 생각하고 글시 색감에 신경쓰세요 "
    ]
    if layout_type:
        prompt_parts.append(f"레이아웃 타입: {layout_type}")
    
    response = client.models.generate_content(
        model=model,
        contents=[
            "\n".join(prompt_parts),
            types.Part.from_bytes(base_image, mime_type="image/png"),
        ],
    )
    
    # 실제 응답 구조는 공식 docs 보고 맞춰야 함.
    # 여기서는 pseudo-code 예시.
    new_img_bytes = response.candidates[0].content.parts[0].inline_data.data
    return new_img_bytes

# ------------------------------------
# 5) FastAPI 엔드포인트
# ------------------------------------

