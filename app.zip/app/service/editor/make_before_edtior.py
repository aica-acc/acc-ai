"""
OCR -> ClipDrop remove-text 파이프라인 (배너 여러 장 배치 처리 버전)

필수 라이브러리:
    pip install paddleocr paddlepaddle==2.5.0
    pip install opencv-python pillow requests python-dotenv

환경변수:
    CLIPDROP_API_KEY=your_api_key_here
"""

import os
from typing import List, Dict, Any
import json
import cv2
import numpy as np
from paddleocr import PaddleOCR
from PIL import Image  # 현재는 안 쓰지만, 확장용으로 남겨둠
import requests
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()
CLIPDROP_API_KEY = os.getenv("CLIPDROP_API_KEY")

# 🔧 경로 기본값 (필요하면 여기만 수정해서 프로젝트 경로 맞추면 됨)
EDITOR_ROOT_DIR = r"C:\final_project\ACC\acc-ai\app\data\editor"
OUTPUT_ROOT_DIR = r"./output_editor"

# ==============================
# 2. ClipDrop remove-text 호출
# ==============================
def call_clipdrop_remove_text(image_path: str, output_image_path: str) -> None:
    if not CLIPDROP_API_KEY:
        raise RuntimeError("CLIPDROP_API_KEY 비어있음")

    url = "https://clipdrop-api.co/remove-text/v1"
    headers = {"x-api-key": CLIPDROP_API_KEY}

    with open(image_path, "rb") as image_file_object:
        files = {
            "image_file": (
                os.path.basename(image_path),
                image_file_object,
                "image/png",
            )
        }

        r = requests.post(url, files=files, headers=headers)

    if r.ok:
        os.makedirs(os.path.dirname(output_image_path), exist_ok=True)
        with open(output_image_path, "wb") as out:
            out.write(r.content)
        print(f"[CLIPDROP] remove-text saved to: {output_image_path}")
    else:
        print("[CLIPDROP ERROR]", r.status_code, r.text)
        r.raise_for_status()


# ==============================
# 3. 한 장 처리 유닛 (type 기반)
# ==============================
def process_poster(
    image_path: str,
    out_root_for_run: str,
    type_name: str,
) -> Dict[str, str]:
    """
    한 장의 포스터에 대해:
      - ClipDrop remove-text 결과
    를 생성하고 경로들을 리턴
    """
    # 폴더 구조:
    #   out_root_for_run/
    #       debug/{type}.png
    #       ocr/{type}.json
    #       clean/{type}.png
    clean_dir = os.path.join(out_root_for_run, "clean")


    os.makedirs(clean_dir, exist_ok=True)

    cleaned_path = os.path.join(clean_dir, f"{type_name}.png")


    # 4) 텍스트 제거 이미지
    call_clipdrop_remove_text(image_path, cleaned_path)

    return {
        "type": type_name,
        "original": image_path,
        "cleaned": cleaned_path,
    }


# ==============================
# 4. 배치 실행 엔트리 (run_id 단위, before_data 기준)
# ==============================
def run(
    run_id: int,
    editor_root: str = EDITOR_ROOT_DIR,
    output_root: str = OUTPUT_ROOT_DIR,
) -> Dict[str, Dict[str, str]]:
    """
    주어진 run_id에 대해:

      - editor/<run_id>/before_data/*.json 을 모두 순회
      - 각 JSON에서:
          - type: "streetlamp-banner"
          - image_path: "C:\\...\\streetlamp_banner_2025....png"
        를 읽어옴
      - image_path 를 실제 OCR + remove-text 대상으로 사용
      - output_editor/<run_id>/debug/{type}.png
                           /ocr/{type}.json
                           /clean/{type}.png 생성

    리턴값 (index.json 형태):
      {
        "streetlamp-banner": {
          "type": "streetlamp-banner",
          "original": "C:\\...\\streetlamp_banner_XXXX.png",
          "debug_overlay": "./output_editor/<run_id>/debug/streetlamp-banner.png",
          "ocr_json":      "./output_editor/<run_id>/ocr/streetlamp-banner.json",
          "cleaned":       "./output_editor/<run_id>/clean/streetlamp-banner.png"
        },
        ...
      }
    """
    editor_run_root = os.path.join(editor_root, str(run_id))
    before_data_dir = os.path.join(editor_run_root, "before_data")

    if not os.path.isdir(before_data_dir):
        raise FileNotFoundError(f"before_data dir not found: {before_data_dir}")

    output_run_dir = os.path.join(output_root, str(run_id))
    os.makedirs(output_run_dir, exist_ok=True)

    # before_data/*.json 순회
    json_files = [
        f for f in os.listdir(before_data_dir)
        if f.lower().endswith(".json")
    ]
    json_files.sort()

    if not json_files:
        print(f"[RUN] no metadata json found in {before_data_dir}")
        return {}

    results: Dict[str, Dict[str, str]] = {}

    for filename in json_files:
        meta_path = os.path.join(before_data_dir, filename)
        stem = Path(filename).stem

        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)

        # 1) type 이름
        type_name = meta.get("type") or stem

        # 2) 이미지 경로
        image_path = meta.get("image_path")
        if not image_path:
            print(f"[WARN] 'image_path' not found in {meta_path}, skip.")
            continue

        # 상대 경로일 수도 있으니 절대/상대 둘 다 지원
        if not os.path.isabs(image_path):
            # 프로젝트 구조에 맞게 필요하면 여기 조정
            image_path = os.path.abspath(image_path)

        if not os.path.exists(image_path):
            print(f"[WARN] image not found for {type_name}: {image_path}, skip.")
            continue

        print(
            f"\n=== Processing run_id={run_id}, "
            f"type={type_name}, meta_file={filename} ==="
        )

        result_paths = process_poster(
            image_path=image_path,
            out_root_for_run=output_run_dir,
            type_name=type_name,
        )

        # 메타 json 경로도 같이 기록 (LangChain 쪽에서 쓰기 좋게)
        result_paths["before_data"] = meta_path

        results[type_name] = result_paths

    # index.json 저장
    index_json_path = os.path.join(output_run_dir, "index.json")
    with open(index_json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n[RUN] index saved to: {index_json_path}")

    return results


# ==============================
# 5. 테스트 전용 main
# ==============================
if __name__ == "__main__":
    # 테스트할 때만 직접 호출
    TEST_RUN_ID = 5
    run(TEST_RUN_ID)
