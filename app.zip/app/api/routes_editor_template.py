# from __future__ import annotations

# from datetime import datetime
# from pathlib import Path
# from typing import List, Dict, Any, Optional

# from fastapi import APIRouter, HTTPException
# from pydantic import BaseModel

# # 🔹 네가 만든 파이프라인 함수들 import (모듈명은 실제 위치에 맞게)
# #   - OCR + ClipDrop + index.json: make_before_edtior.run
# #   - 레이아웃 생성: mkake_after_editor.build_and_save_all_layouts_for_run
# from app.service.editor.make_before_edtior import (
#     run as run_before,
#     EDITOR_ROOT_DIR,
#     OUTPUT_ROOT_DIR,
# )
# from app.service.editor.mkake_after_editor import (
#     build_and_save_all_layouts_for_run,
# )

# # 🔹 타입별 템플릿 생성 함수들 (run_{type}_to_editor)
# from app.service.editor.make_templates import (
#     run_road_banner_to_editor,
#     run_streetlamp_banner_to_editor,
#     run_general_bus_driveway_to_editor,
#     run_medium_bus_driveway_to_editor,
#     run_all_bus_drivewayT_to_editor,
#     run_general_bus_sidewalkT_to_editor,
#     run_hyundai_bus_sidewalkT_to_editor,
#     run_daewoo_bus_sidewalkT_to_editor,
#     run_medium_bus_sidewalkT_to_editor,
#     run_general_bus_getoff_to_editor,
#     run_medium_bus_getoff_to_editor,
# )

# # 🔹 cleaned 이미지가 static으로 떠 있는 URL prefix
# #    실제로는 Flask/uvicorn static 설정에서 이 경로로 노출되도록 맞춰줘야 함
# EDITOR_IMAGE_URL_ROOT = "http://127.0.0.1:5000/static/editor_images"

# router = APIRouter(prefix="/editor", tags=["Editor Build"])


# # ===========================
# #  Pydantic 모델
# # ===========================

# class PosterIn(BaseModel):
#     posterImageUrl: str        # 참고 포스터 절대 경로
#     title: str                 # 축제명 (KO)
#     festivalStartDate: str     # "2025-11-03"
#     festivalEndDate: str       # "2025-11-06"
#     location: str              # 장소 (KO)
#     types: List[str]           # ["road_banner", "all_bus_drivewayT", ...]


# class EditorBuildRequest(BaseModel):
#     pNo: int                   # 지금은 내부에서 안 쓰지만 형식 맞추려고 포함
#     posters: List[PosterIn]


# class TemplateResult(BaseModel):
#     type: str                  # road_banner 등
#     filePath: str              # layout json 경로 (output_editor/...)
#     cleanImageUrl: Optional[str] = None  # inpainting 결과 URL


# class PythonBuildResponse(BaseModel):
#     runId: int
#     results: List[TemplateResult]


# # ===========================
# #  유틸 함수들
# # ===========================

# def get_next_run_id() -> int:
#     """
#     editor_root(EDITOR_ROOT_DIR) 밑 숫자 폴더들 중 max + 1.
#     아무것도 없으면 1부터 시작.
#     """
#     root = Path(EDITOR_ROOT_DIR)
#     root.mkdir(parents=True, exist_ok=True)

#     nums: List[int] = []
#     for child in root.iterdir():
#         if child.is_dir() and child.name.isdigit():
#             nums.append(int(child.name))

#     if not nums:
#         return 1
#     return max(nums) + 1


# def format_period_ko(start_str: str, end_str: str) -> str:
#     """
#     "2025-11-03", "2025-11-06"
#       -> "2025.11.03 ~ 2025.11.06"
#     """
#     try:
#         start_dt = datetime.strptime(start_str, "%Y-%m-%d")
#         end_dt = datetime.strptime(end_str, "%Y-%m-%d")
#     except ValueError:
#         raise HTTPException(status_code=400, detail=f"Invalid date format: {start_str}, {end_str}")

#     start_ko = start_dt.strftime("%Y.%m.%d")
#     end_ko = end_dt.strftime("%Y.%m.%d")
#     return f"{start_ko} ~ {end_ko}"


# def convert_local_path_to_url(path: str) -> str:
#     """
#     clean 이미지 로컬 경로 -> static URL 변환
#     예) .../output_editor/17/clean/road_banner.png
#       -> http://127.0.0.1:5000/static/editor_images/road_banner.png
#     """
#     filename = Path(path).name
#     return f"{EDITOR_IMAGE_URL_ROOT}/{filename}"


# # 🔹 type 문자열 -> 실행 함수 매핑
# TYPE_RUNNER_MAP = {
#     "road_banner": run_road_banner_to_editor,
#     "streetlamp_banner": run_streetlamp_banner_to_editor,
#     "general_bus_driveway": run_general_bus_driveway_to_editor,
#     "medium_bus_driveway": run_medium_bus_driveway_to_editor,
#     "all_bus_drivewayT": run_all_bus_drivewayT_to_editor,
#     "general_bus_sidewalkT": run_general_bus_sidewalkT_to_editor,
#     "hyundai_bus_sidewalkT": run_hyundai_bus_sidewalkT_to_editor,
#     "daewoo_bus_sidewalkT": run_daewoo_bus_sidewalkT_to_editor,
#     "medium_bus_sidewalkT": run_medium_bus_sidewalkT_to_editor,
#     "general_bus_getoff": run_general_bus_getoff_to_editor,
#     "medium_bus_getoff": run_medium_bus_getoff_to_editor,
# }


# # ===========================
# #  메인 라우트
# # ===========================

# @router.post("/build", response_model=PythonBuildResponse)
# async def build_editor_templates(req: EditorBuildRequest):
#     """
#     Spring(ACC-BACKEND)에서 JSON으로 호출:

#     {
#       "pNo": 40,
#       "posters": [
#         {
#           "posterImageUrl": "절대경로",
#           "title": "담양 산타 축제",
#           "festivalStartDate": "2025-11-03",
#           "festivalEndDate": "2025-11-06",
#           "location": "메타랜드 일원",
#           "types": ["road_banner", "all_bus_drivewayT"]
#         },
#         ...
#       ]
#     }

#     파이프라인:
#       1) run_id 계산 (editor/<run_id>)
#       2) 모든 poster × type 에 대해 run_{type}_to_editor(...)
#       3) run_before(run_id)  # OCR + ClipDrop + index.json
#       4) build_and_save_all_layouts_for_run(run_id)
#          -> {type: layout_json_path}
#       5) layout_path & clean 이미지 URL로 results 구성해서 반환
#     """
#     try:
#         # 1) run_id 생성
#         run_id = get_next_run_id()

#         # 2) 각 포스터 & 타입별 템플릿 생성
#         for poster in req.posters:
#             period_ko = format_period_ko(
#                 poster.festivalStartDate,
#                 poster.festivalEndDate,
#             )

#             festival_name_ko = poster.title
#             festival_location_ko = poster.location
#             poster_image_url = poster.posterImageUrl

#             for t in poster.types:
#                 runner = TYPE_RUNNER_MAP.get(t)
#                 if runner is None:
#                     raise HTTPException(
#                         status_code=400,
#                         detail=f"Unknown template type: {t}",
#                     )

#                 # 🔥 네가 정의한 시그니처에 맞춰 호출
#                 #   run_{type}_to_editor(
#                 #       run_id: int,
#                 #       poster_image_url: str,
#                 #       festival_name_ko: str,
#                 #       festival_period_ko: str,
#                 #       festival_location_ko: str,
#                 #   )
#                 runner(
#                     run_id=run_id,
#                     poster_image_url=poster_image_url,
#                     festival_name_ko=festival_name_ko,
#                     festival_period_ko=period_ko,
#                     festival_location_ko=festival_location_ko,
#                 )

#         # 3) OCR + ClipDrop + index.json 생성
#         #    (make_before_edtior.run)
#         run_before(run_id=run_id)

#         # 4) 레이아웃 JSON 생성 + 저장
#         #    {type: layout_json_path} 딕셔너리 형태
#         layout_map: Dict[str, str] = build_and_save_all_layouts_for_run(
#             run_id=run_id
#         )

#         results: List[TemplateResult] = []

#         for type_name, layout_path in layout_map.items():
#             # clean 이미지는 output_editor/<run_id>/clean/{type}.png 가정
#             clean_path = Path(OUTPUT_ROOT_DIR) / str(run_id) / "clean" / f"{type_name}.png"
#             clean_url = None
#             if clean_path.is_file():
#                 clean_url = convert_local_path_to_url(str(clean_path))

#             results.append(
#                 TemplateResult(
#                     type=type_name,
#                     filePath=str(layout_path),
#                     cleanImageUrl=clean_url,
#                 )
#             )

#         return PythonBuildResponse(
#             runId=run_id,
#             results=results,
#         )

#     except HTTPException:
#         # 위에서 이미 status_code 지정해서 던진 에러는 그대로 전달
#         raise
#     except Exception as e:
#         print("❌ [editor.build] error:", e)
#         raise HTTPException(status_code=500, detail="Editor build failed")
